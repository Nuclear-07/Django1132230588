import pandas as pd
from django.shortcuts import render

# Create your views here.

def index(request):
    df = pd.read_csv('https://raw.githubusercontent.com/LearnDataSci/articles/master/Python%20Pandas%20Tutorial%20A%20Complete%20Introduction%20for%20Beginners/IMDB-Movie-Data.csv')

    # Handle missing values for revenue
    df['Revenue (Millions)'] = df['Revenue (Millions)'].fillna(0)

    # Aggregate data by genre
    genre_stats = df.groupby('Genre').agg({
        'Rating': 'mean',
        'Revenue (Millions)': 'mean',
        'Runtime (Minutes)': 'mean'
    }).reset_index()

    # Rename columns to avoid issues in template
    genre_stats.columns = ['Genre', 'Average_Rating', 'Average_Revenue', 'Average_Runtime']

    # Convert the genre_stats dataframe to a dictionary for easy rendering in the template
    genre_stats_dict = genre_stats.to_dict(orient='records')

    analysis = {
        'total_movies': df.shape[0],
        'sci_fi_count': df[df['Genre'].str.contains('Sci-Fi', na=False)].shape[0],
        'average_runtime': df['Runtime (Minutes)'].mean(),
        'average_rating': df['Rating'].mean(),
        'average_revenue': df['Revenue (Millions)'].mean(),
        'genre_stats': genre_stats_dict
    }

    return render(request, 'index.html', {'analysis': analysis})
